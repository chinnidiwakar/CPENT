This is a readme file for HTTHost 1.8.5.

HTTHost is a tunneling server for HTTPort. You need it only if you have
a PC outside a proxy/firewall blocked network to install it at.

This package has a console version of HTTHost included. The console version 
may be run as a system service using srvany or similar application.

This package also contains source code for the transfer.dll library, by
modifying that library and using the modified version with both your HTTPort 
and HTTHost you can change the way they talk, the way the data is 
encoded and transferred, you can make HTTPort traffic mimic any conventional
HTTP traffic.

Two security filters are also included which allow sort of a firewall-like 
tuning.

Contents: 
~~~~~~~~~
1. How to configure
3. Security filters
3. Encryption warning
4. Credits

1. How to configure
~~~~~~~~~~~~~~~~~~~
All configuration options are accessible from Options tab. All changes
take place once you click "Apply".

Note: Console version has no interface, so it just reads the htthost.ini file.
You may use the GUI version to adjust all parameters as you like, shutdown
the GUI version so that it saves the ini file, and then run console version
so that it reads in the ini file you are fine with.

* Bind listening to:

This is a DNS name or dotted IP address of the interface to bind HTTHost's 
listening to. It could be 0.0.0.0 which means - bind to all interfaces.

* Port:

This is a port number that HTTHost listens at. 80 is highly recommended.

* Bind external to:

This is a DNS name or dotted IP address of the _external_ interface to bind 
SOCKS server to. Also all outgoing connections made on clients behalf are 
bound to this IP. If you have more than one network card (multihomed system),
this must be not be zero, otherwise SOCKS wont't work. 

It's recommended that you use ipconfig.exe or winipcfg.exe to determine
the IP address assigned to your external (or the only) network card
and enter it here.

Don't leave this at zero !

* Allow access from:

This is an additional security parameter. You may enter DNS name or 
dotted IP of your proxy here. If this field is not 0.0.0.0, HTTHost 
will not accept any connections from address, different than specified 
here.

Recommended - if you know the proxy address which will be representing
you (from HTTHost point of view) - enter it here. If you want to use it
from behind several proxies or you just are unsure, leave as 0.0.0.0
Personal password is checked anyway, no matter what this parameter is.

* Personal password:

This is a security option. Only HTTPort's with the same password will
be allowed to use this host. Note that the security of that password 
is negligible, the hash of that password is transferred in plain with
each request and can be sniffed off the wire. It's recommended that 
you combine this setting with the two other security features - 
Allow access from field and fine security filters tuning.

* Passthrough ...

This turns on HTTHost cloaking feature. If this is checked, HTTHost
will redirect all HTTP requests it can't handle to the server defined
by next three parameters. From outside it looks like your machine is
running a mirror of that external HTTP server.

* Host name:

This is a DNS name or dotted IP address of the HTTP server to mimic. 
Set it to whatever host you like. Note: since version 1.8.5 the 
behaviour of this field has changed. If this field contains a dotted
IP, the redirected requests will have Host: field left intact, whereas
if this field is specified as a non-IP DNS name, the Host: field will
get replaced with exactly it's value. As a rule of thumb - if your
passthrough is set to the same machine on different port, set this
to 127.0.0.1, but if you redirect to some external server, set this
to a fully qualified domain name of that server.

* Port:

This is a port number of the of the HTTP server to mimic. 
Most probably 80.

* Original IP header field:

This is a name for additional request header field, that is added
to the passthrough'ed request. The value will contain the original
address of the client in dotted IP format. Leave blank or enter 
something like X-Original-IP. If you ever care to use this parameter, 
then you must be running the web server on the same machine, use 
passthrough, and log accesses. I believe if you do this you are 
able to understand how to use this setting.

* Max. local buffer:

This is a maximum amount of data that HTTHost will allow single
connection to buffer locally. Ex. if client is sending data
through HTTHost, but the target server is not accepting it
(either it's busy or slow, or doesn't want to talk to us), HTTHost
will buffer up to this amount and then terminate the connection.
If the target server is slow and you are uploading large amounts
of data, you can be experiencing disconnects. This setting
definetely does not solve all the throttle and buffering problems,
and sometimes it can result in weird effects.

* Timeouts:

This specifies the three HTTHost timeouts in seconds.
0:1:2 is the fastest setting, 3:6:9 is the slowest.

* Revalidate DNS names:

This setting must be used along with the DNS names (not IP's), entered
anywhere else. It will force the DNS names to be requeried once
a minute. Turn this on if you have HTTHost running on a PC with dynamic 
DNS record.

* Log connections:

Save log of all the connections in LOGS/htthost.log

2. Security filters
~~~~~~~~~~~~~~~~~~~

HTTHost has an extensible way of controlling the traffic - security
filters, external plug-in DLLs. They get loaded once at startup 
and then used for each tunneled connection. Each loaded filter has a 
range - set of IP addresses and ports to which it applies.

There are two kinds of filters - "connection" filter,
(in case it does not care for the data being transferred), both
block and grant are of that kind), and "data" filter (if it reads 
and possibly modifies the data being tunneled), not included smtp 
filter is one example.

Security filter logic:

1. Client requests tunneling to 'some.host:port'.
2. HTTHost resolves some.host into an IP.
3. HTTHost scans the list of the loaded filters starting with first.
4. The first filter whose range covers this IP:port, wins.
5. Now that HTTHost knows filter for this particular connection, 
   every time it is about to do something that may be of a filter
   interest, ex. - connection attempt, data being sent or received,
   it calls the filter for confirmation or other processing.
   
Personal HTTHost goes with two simple filters of the similar nature - 
block.dll and grant.dll. block.dll forbids tunneling _to_ IPs 
and ports it's ranges cover. grant.dll allows tunneling _to_ IPs 
and ports it's ranges cover.

Security filters configuration is loaded once at startup from the
filters.cfg file, which should reside in HTTHost's directory.
It is suggested, yet not required, that the filters themselves also
reside in the same directory.

The general syntax for the file is:

filter=filter1.dll
range=baseIP,IPmask,basePort,Portmask
...
range=baseIP,IPmask,basePort,Portmask
filter=filter2.dll
range=baseIP,IPmask,basePort,Portmask
...
range=baseIP,IPmask,basePort,Portmask
....
filter=filterN.dll
range=baseIP,IPmask,basePort,Portmask
...
range=baseIP,IPmask,basePort,Portmask

Example 1: 

You want your clients to use HTTHost to open tunnels to server1:7777 and
server2:8888 only. Assuming server1's IP is 111.11.11.11, and 
server2's IP is 222.22.22.22, the following configuration will do the trick:

- ----------- filters.cfg, example 1 --------------

filter=grant.dll
range=111.11.11.11,0.0.0.0,7777,0
range=222.22.22.22,0.0.0.0,8888,0
filter=block.dll
range=0.0.0.0,255.255.255.255,0,65535

- -------------------------------------------------

Example 2:

You want your clients to use HTTHost to open tunnels to any host
within C-class subnet of 123.45.67.* on ports above 1024 only.
You should make a copy of block.dll, let's say block2.dll.
This way you can duplicate filters entries in the cfg file.

- ----------- filters.cfg, example 2 --------------

filter=block.dll
range=123.45.67.0,0.0.0.255,0,1023
filter=grant.dll
range=123.45.67.0,0.0.0.255,0,65535
filter=block2.dll
range=0.0.0.0,255.255.255.255,0,65535

- -------------------------------------------------

3. Encryption warning
~~~~~~~~~~~~~~~~~~~~~
Anybody can download this personal HTTHost, just like you did.
And it comes with the same private host key (htthost.pri) for 
everybody. This means that ANYBODY CAN DECRYPT YOUR TRAFFIC.
It's not a matter of breaking the cypher, because THEY KNOW
THE KEY. It's only the matter of reverse engineering.

Don't feel safe with the key available to anybody !

If you wish to obtain your own unique key, please visit the site
at http://www.htthost.com/ and see the appropriate
section.

4. Credits
~~~~~~~~~~

HTTPort and HTTHost are written by Dmitry Dvoinikov.
http://www.targeted.org/

(c) 1999-2004, Dmitry Dvoinikov

Support is provided by Technology Networks LLC.
http://www.technetva.com/

Dmitry Dvoinikov 
Aug 22, 2004
